import React from "react";

export const RecipieComments = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  return <div>{children}</div>;
};
