import React from "react";
import Image, { ImageProps } from "next/image";
export const FoodieLogo = (props: ImageProps) => {
  return <Image {...props} />;
};
