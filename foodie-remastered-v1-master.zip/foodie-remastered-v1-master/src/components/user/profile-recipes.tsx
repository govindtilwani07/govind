import React from "react";

const ProfileRecipes = () => {
  return <div>ProfileRecipes</div>;
};

export default ProfileRecipes;
