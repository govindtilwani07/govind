CREATE TABLE IF NOT EXISTS "user_follow" (
	"userId" text NOT NULL,
	"followerId" text NOT NULL
);
